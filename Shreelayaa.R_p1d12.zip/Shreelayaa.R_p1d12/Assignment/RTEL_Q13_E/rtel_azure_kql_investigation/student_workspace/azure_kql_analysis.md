# Azure Kusto Query Language (KQL) Exception Tracking Report
 
> **Telemetry Reference Note:** The provided JSON telemetry (`appin-ecommerce-prod-eastus`, `subscription_id`: `sub-az-892341`, `time_range`: `ago(24h)`) uses operation IDs `op-8921-az` through `op-8925-az` and dependency targets `sql-ecommerce-prod.database.windows.net | OrderDb`, `cosmosdb-catalog-prod.documents.azure.com`, `redis-cache-prod.redis.cache.windows.net:6380`, and `https://payments.partner-api.com`. The tables below reflect the actual telemetry data provided (`op-982141-a1`–`op-982143-c3` and `api.stripe.com` are not present in the JSON).
 
## 1. KQL Investigation Queries
Document the primary KQL queries formulated to investigate application errors and failing dependencies from `azure_kql_telemetry.json`:
 
### Query 1: Filter Failing Requests with Error Details
```kql
requests
| where timestamp > ago(24h)
| where success == false
| project timestamp, id, operation_Id, cloud_RoleName, name, resultCode, duration, user_AuthenticatedId
| order by timestamp asc
```
 
### Query 2: Correlate Requests with Unhandled C# Exceptions via Join
```kql
requests
| where timestamp > ago(24h)
| join kind=inner (
    exceptions
    | project operation_Id, exceptionTimestamp = timestamp, type, problemId, method, outerMessage, severityLevel, handledAt
) on operation_Id
| project timestamp, operation_Id, cloud_RoleName, name, resultCode, duration, type, method, outerMessage, handledAt
| order by timestamp asc
```
 
### Query 3: Dependency Failure Rate & Duration Mapping
```kql
dependencies
| where timestamp > ago(24h)
| summarize
    TotalCalls = count(),
    FailedCalls = countif(success == false),
    AvgDurationMs = round(avg(duration), 2)
  by target, type
| extend FailureRatePct = round(100.0 * FailedCalls / TotalCalls, 2)
| order by FailureRatePct desc, AvgDurationMs desc
```
 
### Query 4: Time-Series Error Render
```kql
requests
| where timestamp > ago(24h)
| where success == false
| summarize FailedRequests = count() by bin(timestamp, 1m), cloud_RoleName, resultCode
| render timechart
```
 
---
 
## 2. Request-to-Exception Correlation Breakdown
Based on the inner join of `requests` and `exceptions` using `operation_Id`, complete the correlation matrix:
 
| Operation ID | Request Name | Result Code | Exception Class | Method Name | Root Cause Message |
|---|---|---|---|---|---|
| `op-8921-az` *(template placeholder `op-982141-a1`)* | `POST /api/v2/orders/checkout` | `500` | `System.Data.SqlClient.SqlException` | `OrderRepository.SaveOrderAsync` | Execution Timeout Expired. The timeout period elapsed prior to completion of the operation or the server is not responding. |
| `op-8922-az` *(template placeholder `op-982142-b2`)* | `POST /api/v2/orders/checkout` | `500` | `System.Data.SqlClient.SqlException` | `OrderRepository.SaveOrderAsync` | Execution Timeout Expired. The timeout period elapsed prior to completion of the operation or the server is not responding. |
| `op-8925-az` *(template placeholder `op-982143-c3`)* | `POST /api/v2/orders/checkout` | `504` | `System.Net.Http.HttpRequestException` | `PaymentGatewayClient.AuthorizeCharge` | The remote server returned an error: (504) Gateway Timeout. |
 
---
 
## 3. Downstream Dependency Failure Rate Matrix
Summarize dependency calls grouped by target and type:
 
| Dependency Target | Dependency Type | Total Calls | Failed Calls | Failure Rate (%) | Avg Duration (ms) | Operational Health |
|---|---|---|---|---|---|---|
| `sql-ecommerce-prod.database.windows.net \| OrderDb` *(template: `sql-orders-primary.database.windows.net`)* | SQL | 2 | 2 | 100.0% | 3035.0 | Unhealthy / Degraded (SQL timeouts) |
| `https://payments.partner-api.com` *(template: `api.stripe.com`)* | HTTP | 1 | 1 | 100.0% | 4980.0 | Unhealthy / Degraded (Gateway 504 timeout) |
| `redis-cache-prod.redis.cache.windows.net:6380` *(template: `redis-cache.redis.cache.windows.net`)* | Redis | 1 | 0 | 0.0% | 3.2 | Healthy |
| `cosmosdb-catalog-prod.documents.azure.com` *(additional target in JSON)* | Azure DocumentDB | 1 | 0 | 0.0% | 12.5 | Healthy |
 
---
 
## 4. Root Cause Diagnosis & Alert Rule
<!-- Provide root cause diagnosis and recommended Azure Monitor alerting rule: -->
1. **Primary Root Cause:**
  - *Failing Component:* `OrderingMicroservice` (`POST /api/v2/orders/checkout`), specifically `OrderRepository.SaveOrderAsync` calling `sp_InsertCustomerOrder` on `sql-ecommerce-prod.database.windows.net | OrderDb`, alongside `PaymentGatewayClient.AuthorizeCharge` calling `POST https://payments.partner-api.com/v1/charge`.
  - *Root Cause Explanation:* Checkout requests failed with `500` (`op-8921-az`, `op-8922-az`) when `sp_InsertCustomerOrder` timed out after `3,050.0 ms` and `3,020.0 ms`, throwing `System.Data.SqlClient.SqlException` (`Execution Timeout Expired`), and with `504` (`op-8925-az`) when `https://payments.partner-api.com/v1/charge` timed out after `4,980.0 ms`, throwing `System.Net.Http.HttpRequestException` (`(504) Gateway Timeout`). Meanwhile, catalog (`cosmosdb-catalog-prod.documents.azure.com`, `12.5 ms`) and inventory (`redis-cache-prod.redis.cache.windows.net:6380`, `3.2 ms`) calls succeeded.
 
2. **Azure Monitor Alert Rule Configuration:**
- *Signal Logic:* Log search alert on `appin-ecommerce-prod-eastus` where `requests` has `success == false` and `name == "POST /api/v2/orders/checkout"` (or `exceptions` has `severityLevel >= 3` on `OrderingMicroservice`).
  - *Threshold & Frequency:* Trigger when failed checkout requests or unhandled `severityLevel >= 3` exceptions exceed `2` (or failure rate exceeds `5%`) evaluated every `1 minute` over a `5-minute` lookback window.