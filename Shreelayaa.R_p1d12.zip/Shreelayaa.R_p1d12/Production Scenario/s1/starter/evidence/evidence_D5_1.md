# Incident Evidence: TEL-D5-501 (Top Failing Dependency in Application Insights)

- **Participant Name:** Shreelayaa R
- **Date & Time:** 25-Nov-2026 16:16 IST
- **Ticket ID:** `TEL-D5-501`
- **Course Outcome:** `CO-13`
- **Platform:** Cloud (Azure Application Insights KQL)

## 1. Problem Identification & Initial Observations
- **Observed Failure:** Checkout operations are degraded because calls to a downstream third-party dependency are failing with HTTP 504 Gateway Timeout responses. Initial telemetry does not immediately identify which external vendor is responsible or how the dependency failures correlate with application exceptions.
- **Culprit Service / Host / Component:** api.external-fraud.io
- **Failure rate of the culprit (failed / total = %):** 212 / 500 = 42.4%
- **First failure time (UTC, HH:MM):** 08:15

## 2. Diagnostic Query & Telemetry Evidence
Query 1 — ranking of the dependencies by failures:
```text
dependencies
| where timestamp > ago(4h)
| summarize TotalCalls = count(), FailedCalls = countif(success == false) by target
| extend FailureRate = round(100.0 * FailedCalls / TotalCalls, 2)
| sort by FailedCalls desc
```
Query 2 — failed calls of the culprit joined with exceptions:
```text
dependencies
| where timestamp > ago(4h) and success == false and target == "api.external-fraud.io"

| join kind=inner (exceptions | where timestamp > ago(4h)) on operation_Id
| project timestamp, operation_Id, target, resultCode, type, innermostMessage
```
Result excerpt (top rows, exception type and message):
```text
api.external-fraud.io | resultCode=504 | System.Threading.Tasks.TaskCanceledException: A task was canceled while waiting for external fraud check response.
```

## 3. Root Cause Analysis (RCA)
The root cause of the checkout degradation is repeated timeout failures from the downstream fraud-detection dependency `api.external-fraud.io`. Application Insights dependency telemetry shows this endpoint as the dominant failing dependency during the four-hour investigation window, with 212 failed calls out of 500 total calls (42.4% failure rate) returning HTTP 504 Gateway Timeout responses.

Correlating failed dependency records with the `exceptions` table via `operation_Id` links the external dependency timeouts directly to `System.Threading.Tasks.TaskCanceledException` exceptions observed in the checkout request path. This establishes the direct relationship between the third-party fraud API timeout and user-facing checkout degradation.

Other dependencies showing failures, specifically `inventory-svc` returning HTTP 404 responses, are not the primary root cause because 404 lookups for out-of-stock or uncatalogued items are expected normal behavior rather than an incident. Unlike `api.external-fraud.io`, `inventory-svc` does not exhibit timeouts or correlated unhandled exceptions blocking the checkout workflow.

## 4. Verification & Solution Details
- **Fixed Metric / Rule / Parameter:** Verified dependency-failure analysis using `success == false`, grouped failures by `target`, calculated per-target failure rates, and correlated failed dependency calls with application exceptions using `operation_Id`.
- **Observed Result After Fix:** The diagnostic telemetry now isolates `api.external-fraud.io` as the failing downstream dependency and correlates its HTTP 504 timeout failures with the corresponding checkout `TaskCanceledException` exceptions.
- **Recommended Action Item:** Escalate availability and latency issues to the `api.external-fraud.io` vendor; configure appropriate outbound request timeouts and bounded retries with exponential backoff; add an Application Insights alert for elevated dependency failure rates and 504 responses; and implement graceful degradation or a circuit-breaker policy so fraud-provider outages do not cause uncontrolled checkout degradation.
