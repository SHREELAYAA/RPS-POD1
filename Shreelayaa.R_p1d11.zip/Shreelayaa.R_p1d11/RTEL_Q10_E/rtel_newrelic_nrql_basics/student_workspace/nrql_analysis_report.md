# New Relic NRQL Querying & Performance Audit Report

## 1. Top Slowest Transactions Audit
Identify the top slow database and web transactions recorded across the environment from `nrql_slow_transactions.json`:

- **Transaction 1**:
  - *Name:* 
  - *Max Duration (s):* 
  - *Database Duration (s):* 
  - *HTTP Status / Error:* 
  - *Primary Bottleneck:* 

- **Transaction 2**:
  - *Name:* 
  - *Max Duration (s):* 
  - *External Duration (s):* 
  - *HTTP Status / Error:* 
  - *Primary Bottleneck:* 

- **Transaction 3**:
  - *Name:* 
  - *Max Duration (s):* 
  - *Database Duration (s):* 
  - *HTTP Status / Error:* 
  - *Primary Bottleneck:* 

---

## 2. NRQL Query Formulations
Document the NRQL queries constructed to extract slow transaction performance data:

### Query 1: Top 10 Slowest Transactions by Average Duration
```sql
-- Write your NRQL query here:

```

### Query 2: Duration Percentile Aggregations (P50, P90, P95, P99)
```sql
-- Write your NRQL query here:

```

### Query 3: Time-Series Error Rate Trends
```sql
-- Write your NRQL query here:

```

---

## 3. Latency Percentile Distribution
Based on the aggregated metrics in the dataset, record the percentile thresholds:

| Metric Dimension | P50 (ms) | P90 (ms) | P95 (ms) | P99 (ms) | Operational Assessment |
|---|---|---|---|---|---|
| `order-service-prod` | | | | | |
| `catalog-service-prod` | | | | | |
| `payment-gateway-prod` | | | | | |

---

## 4. Root Cause Diagnosis & Remediation Strategy
<!-- Document 3 concrete architectural recommendations (e.g., query indexing, lock reduction, third-party circuit breakers) based on your findings: -->
1. **Database Row Lock Contention (`orders` table):**
   - *Recommendation:* 

2. **External Gateway Latency (`Stripe API`):**
   - *Recommendation:* 

3. **Full Table Scan on Catalog (`LIKE '%...'`):**
   - *Recommendation:* 
